<div class="container">
	<div class="row">
		<div class="col-sm-12">
			<div class="alert alert-primary" role="alert">
				<a href="#" class="alert-link">Your reservation has successfully done.</a>
			</div>
		</div>
	</div>
</div>