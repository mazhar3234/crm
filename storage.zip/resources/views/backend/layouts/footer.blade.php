<!-- footer start here -->
<div class="app-wrapper-footer">
    <div class="app-footer">
        <div class="app-footer__inner">
            <div class="app-footer-left">
            </div>
            <div class="app-footer-right">
            	<strong>Copyright &copy; {{ date('Y') }} <a target="_blank" href="https://moazzamhossain7.github.io/">MOAZZAM.</a></strong> All rights reserved.
            </div>
        </div>
    </div>
</div>
<!-- footer end here -->