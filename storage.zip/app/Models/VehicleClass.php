<?php
/**
 * Model    : Vehicle Class
 * @author  : Moazzam <en.moazzam@gmail.com>
 * Created  : 27 January, 2020
 */
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VehicleClass extends Model
{
    //
}
