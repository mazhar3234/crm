<?php $__env->startSection('content'); ?>

<!-- main content start here -->
<div class="app-main__inner">
    <!-- page title section -->
    <div class="app-page-title app-page-shadow mb-2">
        <div class="page-title-wrapper">
            <div class="page-title-heading col-12 col-md-12 col-sm-12">
              
                <div class="page-title-content">
                    Update Company Information
                </div>
            </div>
        </div>
    </div>
    <?php echo e(Form::open(['route'=>'update-company-info.post', 'id'=>'signupForm', 'novalidate'])); ?>

        <!-- content area -->
        <div class="main-content custom-padding" style="padding-top: 10px;">
            <div class="main-card card custom-card">
                <div class="card-body">
                    <div class="row pb-4">
                        
                        <div class="form-section col-md-8 col-sm-8 col-12">
                            <div class="position-relative row form-group">
                                <label class="col-sm-3 col-form-label custom-label">
                                   About Company In English
                                </label>
                                <div class="col-sm-9">
                                    <textarea class="form-control" name="about_en" required=""><?php echo e($company->about_en); ?></textarea>
                                    
                                </div>
                            </div>
                            <div class="position-relative row form-group">
                                <label class="col-sm-3 col-form-label custom-label">
                                   About Company In Russia
                                </label>
                                <div class="col-sm-9">
                                    <textarea class="form-control" name="about_rs" required=""><?php echo e($company->about_rs); ?></textarea>
                                    
                                </div>
                            </div>
                            <div class="position-relative row form-group">
                                <label class="col-sm-3 col-form-label custom-label">
                                   Address
                                </label>
                                <div class="col-sm-9">
                                    <input class="form-control" type="text" name="address" value="<?php echo e($company->address); ?>" placeholder="" required="">      
                                </div>
                            </div>
                                <div class="position-relative row form-group">
                                <label class="col-sm-3 col-form-label custom-label">
                                   Email
                                </label>
                                <div class="col-sm-9">
                                    <input class="form-control" type="email" name="email" value="<?php echo e($company->email); ?>" placeholder="" required="">      
                                </div>
                            </div>
                                <div class="position-relative row form-group">
                                <label class="col-sm-3 col-form-label custom-label">
                                   Phone Number
                                </label>
                                <div class="col-sm-9">
                                    <input class="form-control" type="text" name="phone" value="<?php echo e($company->phone); ?>" placeholder="" required="">      
                                </div>
                            </div>
                                <div class="position-relative row form-group">
                                <label class="col-sm-3 col-form-label custom-label">
                                  Company Address Latitude
                                </label>
                                <div class="col-sm-9">
                                    <input class="form-control" type="text" name="lat" value="<?php echo e($company->lat); ?>" placeholder="" required="">      
                                </div>
                            </div>
                                <div class="position-relative row form-group">
                                <label class="col-sm-3 col-form-label custom-label">
                                   Company Address Longitude 
                                </label>
                                <div class="col-sm-9">
                                    <input class="form-control" type="text" name="lang" value="<?php echo e($company->lang); ?>" placeholder="" required="">      
                                </div>
                            </div>
                               <div class="position-relative row form-group">
                                <label class="col-sm-3 col-form-label custom-label">
                                   Facebook Link 
                                </label>
                                <div class="col-sm-9">
                                    <input class="form-control" type="text" name="fb" value="<?php echo e($company->fb); ?>" placeholder="">      
                                </div>
                            </div>
                               <div class="position-relative row form-group">
                                <label class="col-sm-3 col-form-label custom-label">
                                   Twitter Link 
                                </label>
                                <div class="col-sm-9">
                                    <input class="form-control" type="text" name="twt" value="<?php echo e($company->twt); ?>" placeholder="">      
                                </div>
                            </div>
                               <div class="position-relative row form-group">
                                <label class="col-sm-3 col-form-label custom-label">
                                   Linkedin Link 
                                </label>
                                <div class="col-sm-9">
                                    <input class="form-control" type="text" name="link" value="<?php echo e($company->link); ?>" placeholder="">      
                                </div>
                            </div>
                               <div class="position-relative row form-group">
                                <label class="col-sm-3 col-form-label custom-label">
                                   Instagram Link 
                                </label>
                                <div class="col-sm-9">
                                    <input class="form-control" type="text" name="ins" value="<?php echo e($company->ins); ?>" placeholder="">      
                                </div>
                            </div>
                            <div class="position-relative row form-group">
                                <label for="exampleEmail" class="col-sm-2 col-form-label custom-label">
                                </label>
                                <div class="col-sm-10">
                                    <button type="submit" class="btn btn-primary custom-btn-submit float-right">Update</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <input type="hidden" name="info_id" value="<?php echo e($company->info_id); ?>">
    <?php echo e(Form::close()); ?>

</div>
<!-- main content end here -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.3\htdocs\crm\resources\views/backend/company/edit.blade.php ENDPATH**/ ?>