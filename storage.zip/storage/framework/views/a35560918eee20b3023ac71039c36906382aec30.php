
<?php $__env->startSection('content'); ?>

<style type="text/css">
    .p-2 {
        display: flex;
        float: left;
    }
</style>
<!-- main content start here -->
<div class="app-main__inner">
    <!-- page title section -->
    <div class="app-page-title app-page-shadow mb-2">
        <div class="page-title-wrapper">
            <div class="page-title-heading col-12 col-md-12 col-sm-12">
                <div class="pl-1 pr-2">
                    <a href="<?php echo e(URL::to('/vehicles')); ?>" class="page-back">
                        <i class="fa fa-arrow-left"></i>
                    </a>
                </div>
                <div class="page-title-content">
                    Car Details
                </div>
            </div>
        </div>
    </div>

    <!-- content area -->
    <div class="main-content custom-padding" style="padding-top: 10px;">
        <div class="row">
		    <div class="col-md-12">
		        <div class="main-card mb-3 card">
		            <div class="card-header">
		            	<span style="font-weight: 500; color: red;"><?php echo e($vehicle->vehicle_name); ?> &nbsp;</span>  
		            	details
		            </div>
		            <div class="table-responsive">
		                <table class="align-middle mb-0 table table-borderless table-striped">
		                    <tbody>
		                        <tr>
		                            <td class="text-center text-muted" width="20%">
		                            	<img src="<?php echo e(asset('/backend/images/vehicles/'.$vehicle->image)); ?>" width="200" height="150" class="rounded m-2">
		                            </td>
		                            <td class="text-center" width="30%">
                                        <strong class="font-size-lg">
                                        	Class : <?php echo e($vehicle->vehicleClass->class_name); ?>

                                        </strong>
                                        <div class="widget-subheading pt-3 font-size-lg"><i>
                                        	<?php echo e($vehicle->vehicle_name); ?>

                                        </i></div>
		                            </td>
		                            <td class="text-center" width="20%">
                                        <div class="widget-subheading">
                                        	<i>Fuel Type: <div class="badge badge-success"> <?php echo e($vehicle->fuel_type); ?> </div></i>
                                    	</div>
                                    	<div class="widget-subheading pt-2">
                                        	<i>Seats : <div class="badge badge-primary"> <?php echo e($vehicle->seats); ?> </div></i>
                                    	</div>
                                    	<div class="widget-subheading pt-2">
                                        	<i>Reg. No: <div class="badge badge-warning"> <?php echo e($vehicle->registration_no); ?> </div></i>
                                    	</div>
		                            </td>
		                            <td class="text-center font-size-lg" width="30%">
                                        Driver: <strong><?php echo e($vehicle->driver->driver_name); ?></strong>
                                        <div class="widget-subheading pt-3 font-size-md" style="color:#111e5f;"><i>
                                        	<?php echo e($vehicle->driver->language); ?>

                                        </i></div>
		                            </td>
		                        </tr>
		                    </tbody>
		                </table>
		            </div>
		        </div>
		    </div>
		</div>

        <div class="row">
            <div class="col-md-12">
                <div class="main-card mb-3 card">
                    <div class="card-header">
                        <span style="font-weight: 500; color: red;"><?php echo e($vehicle->vehicle_name); ?> &nbsp;</span>  
                        Price Info
                    </div>
                    <div class="table-responsive">
                        <table class="align-middle mb-0 table table-borderless table-striped">
                            <?php $__currentLoopData = Helper::getVehiclePrice($vehicle->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="p-2">
                                    <button class="btn-icon-vertical btn-hover-shine pt-2 pb-2 btn btn-outline-secondary active">
                                        From: <?php echo e($slot->from_km); ?> To <?php echo e($slot->to_km); ?> KM <br>
                                        <div class="widget-numbers text-success fsize-1"><span>USD: <?php echo e($slot->amount_usd); ?></span></div>
                                        <div class="widget-numbers text-success fsize-1"><span>GEL: <?php echo e($slot->amount_gel); ?></span></div>
                                        <div class="widget-numbers text-success fsize-1"><span>RUB: <?php echo e($slot->amount_rub); ?></span></div>
                                    </button>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="main-card mb-3 card">
                    <div class="card-header">
                        <span style="font-weight: 500; color: red;"><?php echo e($vehicle->driver->driver_name); ?> &nbsp;</span>  
                        details
                    </div>
                    <div class="table-responsive">
                        <table class="align-middle mb-0 table table-borderless table-striped">
                            <tbody>
                                <tr>
                                    <td class="text-center text-muted" width="20%">
                                        <img src="<?php echo e(asset('/backend/images/drivers/'.$vehicle->driver->image)); ?>" width="200" height="150" class="rounded m-2">
                                    </td>
                                    <td class="text-center" width="30%">
                                        <strong class="font-size-lg">
                                            Name : <?php echo e($vehicle->driver->driver_name); ?>

                                        </strong>
                                        <div class="widget-subheading pt-3 font-size-lg">
                                            Email : <i><?php echo e($vehicle->driver->email); ?></i>
                                        </div>
                                        <div class="widget-subheading pt-3 font-size-lg">
                                            Language : <i><?php echo e($vehicle->driver->language); ?></i>
                                        </div>
                                    </td>
                                    <td class="text-center" width="20%">
                                        <strong class="font-size-lg">
                                            About:<br>
                                        </strong>
                                        <?php echo e($vehicle->driver->description); ?>

                                    </td>
                                    
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- main content end here -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moazz/public_html/crm/resources/views/backend/vehicles/details_vehicle.blade.php ENDPATH**/ ?>