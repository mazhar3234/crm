
<?php $__env->startSection('content'); ?>

<!-- main banner -->
<section class="p-0 height-700 parallax-bg tourBanner" style="background:url(/frontend/images/slider/slider_2.jpg) no-repeat 65% 0%; background-size:cover;">
    <div class="container h-100">
        <div class="row justify-content-between align-items-center h-100">
            <!-- <div class="col-md-8 mb-7">
                <h4>World's biggest online car rental service</h4>
                <h1 class="display-4 font-weight-bold">
                    Upto 25% off on first booking through your app
                </h1>
            </div> -->
        </div>
    </div>
</section>
<!-- main banner -->

<!-- booking section -->
<section class="mt-lg-n9 mt-sm-0 pb-0 z-index-9 booking-search custom-margin" id="booking">
    <div class="container ">
        <div class="row shadow border-radius-3">
            <div class="col-md-12 np">
                <div class="feature-box h-100">
                    <div class="tab_container">
                        <input id="tab1" type="radio" name="tabs" checked>
                        <!-- <label for="tab1"><i class="fas fa-car-side"></i><span>Cars</span></label> -->
                       
                        <section id="content1" class="tab-content" id="booking-data">
                            <div class="row" id="mainDiv">
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 padding8">
                                    <select class="from-control from-location select2" name="from_location[]" onchange="loadCars()" id="from_location">
                                        <option value="">От: Аэропорт Кутаиси</option>
                                        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($location->location_name); ?>"><?php echo e($location->location_name_rus); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 padding8">
                                    <select class="from-control to-location select2" name="to_location[]" onchange="loadCars()" id="to_location">
                                        <option value="">В: Международный аэропорт Батуми</option>
                                        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($location->location_name); ?>"><?php echo e($location->location_name_rus); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="copyDiv"></div>
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding8">
                                    <div class="form-group">
                                        <button class="btn btn-light btn-lg" type="button" id="add_location">
                                           <i class="fas fa-plus"></i> Добавить место
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding8">
                                    <div class="form-group"><span class="far fa-calendar-alt"></span>
                                        <input class="form-control" type="text" id="datepicker" autocomplete="off" placeholder="когда...">
                                    </div>
                                </div> 
                            </div>
                            <p id="tripInfo" style="color: #F49122; font-size: 15px; font-weight: bold;"></p>
                        </section>
                        <input type="hidden" name="duration" id="duration">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end booking section -->

<div id="carOutput"></div>

<!-- service section -->
<section class="bg-light bg-transparent pt80 pb60 solutions mt-custom">
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto text-center mb-5">
                <h2 class="title text-center">
                    МЫ ПРЕДЛАГАЕМ ВАМ
                </h2>
               
            </div>
        </div>
             <div class="row">
            <div class="col-md-6">
                <ul class="list-group list-unstyled">
  <li class="mb-3"><h4 style="font-size: 22px;"><i class="fas fa-thumbs-up"></i>  Автомобили с  подготовительными водителями</h4></li>
   <li class="mb-3"><h4 style="font-size: 22px;"><i class="fas fa-thumbs-up"></i>  Водители, которые сосредоточены на ваших желаниях и потреблении</h4></li>
    <li class="mb-3"><h4 style="font-size: 22px;"><i class="fas fa-thumbs-up"></i>  Комфорт и безопасность</h4></li>
     <li><h4 style="font-size: 22px;"><i class="fas fa-thumbs-up"></i>  Связ в течение 24/7</h4></li>
</ul>
            </div>
            <div class="col-md-6">
                                <ul class="list-group list-unstyled">
  <li class="mb-3"><h4 style="font-size: 22px;"><i class="fas fa-thumbs-up"></i>   Незабываемое путешествие в Грузию</h4></li>
   <li class="mb-3"><h4 style="font-size: 22px;"><i class="fas fa-thumbs-up"></i> Обмен валюты, покупки, селфи и т. д. (На ваше усмотрение)</h4></li>
    <li class="mb-3"><h4 style="font-size: 22px;"><i class="fas fa-thumbs-up"></i> Остановка у всех достопримечательностей по пути</h4></li>
     <li><h4 style="font-size: 22px;"><i class="fas fa-thumbs-up"></i> Лучшую цену, лучший сервис</h4></li>
</ul>
            </div>
        </div>
         <h4 style="font-size: 22px;margin-bottom:10px;" class="mt-5">
           Сайт создан для удобного, надежного и простого поиска вашего личного автомобиля с местными водителями.</h4>

<h4 style="font-size: 22px;margin-bottom:10px;">Наша база данных будет содержать информацию о каждом предложении, точную стоимость трансфера, характеристики водителя и автомобиля, профиль водителя и их знание языков.</h4>

<h4 style="font-size: 22px;margin-bottom:10px;">Для выбора трансфера / тура вам необходимо будет указать место получения и высадки.</h4>

<h4 style="font-size: 22px;margin-bottom:10px;">Ценообразование соответствует услугам по сравнению с конкурентными. Мы предлагаем вам услуги для лучшего обслуживания, хорошо обученных водителей, которые будут сосредоточены на ваших интересах и удобстве.</h4>

<h4  style="font-size: 22px;margin-bottom:10px;">С нашими водителями у вас есть возможность остановиться и насладиться дополнительными достопримечательностями и прекрасными видами, которыми вы можете следовать по маршруту и делать фотографии.
        </h4>
        <h4  style="font-size: 22px;margin-bottom:10px;">Путешествие с местным водителем дает вам возможность сразу почувствовать оригинальность и самобытность культуры Грузии и спокойно насладиться ими.
        </h4>

        <h1 style="margin-top:50px;" class="text-center">
Желаем вам интересно провести время в Грузию</h1>
      
    </div>
</section>
<!-- end service section -->

<!-- popular cities section -->

<!-- end popular cities section -->
    



<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moazz/public_html/crm/resources/views/frontend/russian/index.blade.php ENDPATH**/ ?>