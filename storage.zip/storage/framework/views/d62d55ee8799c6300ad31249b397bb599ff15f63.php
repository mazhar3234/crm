<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <!-- meta information -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="description" content="OMS">
    <meta name="msapplication-tap-highlight" content="no">
    <!-- title for this template -->
    <title><?php echo e(config('app.name')); ?></title>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- main css -->
    <?php echo e(Html::style('backend/css/ems_main.css')); ?>

    <!-- custom css -->
    <?php echo e(Html::style('backend/css/custom.min.css')); ?>

    <!-- jquery -->
    <?php echo e(Html::script('backend/js/jquery.min.js')); ?>

</head>

<body><?php /**PATH /home/moazz/public_html/crm/resources/views/backend/layouts/top.blade.php ENDPATH**/ ?>