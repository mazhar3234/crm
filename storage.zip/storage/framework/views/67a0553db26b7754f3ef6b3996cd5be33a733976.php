<style type="text/css">
    table {
        margin-top: 10px;   
    }
    table td, table th {
        border: 1px solid #ddd;
        padding: 8px 8px;
    }
</style>
<div class="main-content custom-padding" style="padding-top: 10px;">
        <section class="invoice">
            <div class="row">
                <div class="col-xs-12">
                    <h2 class="page-header">
                        <img src="<?php echo e(asset('/backend/images/components/logo.png')); ?>">
                    </h2>
                </div>
            </div>
            <!-- info row -->
            <div class="row invoice-info mt-3">
                <!-- /.col -->
                <div class="col-6 col-sm-6 invoice-col">
                    <strong class="fsize-3 text-success"> Client </strong>
                    <address>
                    <strong><?php echo e($reservation->first_name); ?></strong><br>
                    <b>Date:</b> <?php echo e($reservation->date); ?> <?php echo e($reservation->time); ?> <br>
                    <?php echo e($reservation->last_name); ?><br>
                    Phone: <?php echo e($reservation->mobile_no); ?><br>
                    Email: <?php echo e($reservation->email); ?>

                  </address>
                </div>
                <!-- /.col -->
                <div class="col-6 col-sm-6 invoice-col">
                    <br>
                    <br>
                    <b>Invoice No:</b> <?php echo e($reservation->invoice_id); ?>

                    <br>
                    <b>Payment Due:</b> <?php echo e($reservation->date); ?>

                    <br>
                    <b>Account:</b> <?php echo e($reservation->account); ?>

                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->

            <!-- Table row -->
            <div class="row">
                <div class="col-12 table-responsive">
                    <table class="table" cellpadding="0" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Car Details</th>
                                <th>Location</th>
                                <th>Extra</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <b>Vehicle:</b>
                                    <span class="fsize-1"> <?php echo e($reservation->vehicle->vehicle_name); ?> </span>
                                </td>
                                <td rowspan="4">
                                    <?php 
                                        $fromIds = explode(',', $reservation->from_location_id);
                                        $toIds = explode(',', $reservation->to_location_id);
                                        $i = 0;
                                    ?>
                                    <?php $__currentLoopData = $fromIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fromId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo Helper::getLocation($fromId, $toIds[$i]); ?>


                                        <?php $i++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>
                                    <b>Distance:</b>
                                    <span class="fsize-1"> <?php echo e($reservation->distance); ?> KM </span>
                                </td>
                                <td rowspan="4" class="text-center">
                                    <strong class="fsize-2"> <?php echo e($reservation->amount); ?> <?php echo e($reservation->currency); ?> </strong>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <b>Reg. No:</b>
                                    <span class="fsize-1"> <?php echo e($reservation->vehicle->registration_no); ?> </span>
                                </td>
                                <td>
                                    <b>Duration:</b>
                                    <span class="fsize-1"> <?php echo e($reservation->duration); ?> </span>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <b>Fuel:</b>
                                    <span class="fsize-1"> <?php echo e($reservation->vehicle->fuel_type); ?> </span>
                                </td>
                                <td>
                                    <b>Pickup:</b>
                                    <span class="fsize-1"> <?php echo e($reservation->pickup_address); ?> </span>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <b>Seats:</b>
                                    <span class="fsize-1"> <?php echo e($reservation->vehicle->seats); ?> </span>
                                </td>
                                <td>
                                    <b>Dropoff:</b>
                                    <span class="fsize-1"> <?php echo e($reservation->dropof_address); ?> </span>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <!-- /.col -->
            </div>
        </section>
    </div>
<?php /**PATH /home/moazz/public_html/crm/resources/views/frontend/email/reservation.blade.php ENDPATH**/ ?>