
<section class="Categories pt60 TourHotels custom-section cars bg-transparent mt-custom car-custom">
    <div class="container">
        <form class="form-inline" style="margin-bottom: 20px;">
            <div class="form-group col-md-8">
                <label for="language"><strong>Language: &nbsp;</strong></label>
                <select class="form-control custom-select-field" id="language" onchange="filterCars(this.value)">
                    <option value=""><strong>Choose</strong></option>
                    <option><strong>English</strong></option>
                    <option><strong>Russian</strong></option>
                    <option><strong>Turkish</strong></option>
                    <option><strong>German</strong></option>
                </select>
                &nbsp;&nbsp;
             
                &nbsp;&nbsp;
                <label for="car_type"><strong>Car Type: &nbsp;</strong></label>
                <select class="form-control custom-select-field" id="car_type" onchange="filterCars(this.value)">
                    <option value="">Choose</option>
                    <?php $__currentLoopData = $vehicleClass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($class->class_name); ?>"><?php echo e($class->class_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group col-md-4 sort_by_div">
                <label for="sort_by"><strong>Sort By: &nbsp;</strong></label>
                <select class="form-control custom-select-field" id="sort_by" onchange="sortCars(this.value)">
                    <option value="up">Price increase</option>
                    <option value="down">Price decrease</option>
                </select>
            </div>
        </form>

        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="row" id="vehilcesList">
                    <span id="prev-item"></span>
                    <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                        $price = Helper::getDistancePrice($vehicle->id, $distance);
                    ?>
                    <div class="col-lg-4 col-md-6 col-sm-12 cars-main <?php echo e(str_replace(',', ' ', $vehicle->driver->language)); ?> <?php echo e($vehicle->fuel_type); ?> <?php echo e($vehicle->vehicleClass->class_name); ?>" id="<?php echo e($price); ?>">
                        <div class="listing-item">
                            <article class="TravelGo-category-listing fl-wrap car-item">
                                <div class="rate-class-name">
                                    <div class="row mx-0 mb-2 mt-2 px-2">
                            <?php if($vehicle->driver->language): ?>
                                            <img src="<?php echo e(asset('backend/images/drivers/'.$vehicle->driver->image)); ?>" alt="driver_image" class="img-responsive driver">
                                            <?php else: ?>
                                            <img src="<?php echo e(asset('backend/images/drivers/driver.png')); ?>" alt="driver_image" class="img-responsive driver">
                                            <?php endif; ?>
                            <div class="col-7 pr-0 d-flex flex-column">
                                <a href="javascript:viod(0)">
                                    <span class="driver-name"><?php echo e($vehicle->driver->driver_name); ?></span>
                                </a>
                                <span class="languages">Speaks: <?php echo e($vehicle->driver->language); ?></span>
                            </div>
                            <div class="col-3 pr-0 pl-1 car-type text-center">
                                 <i style="font-size: 24px;" class="fas fa-car-side"></i> <br>
                                <span><?php echo e($vehicle->vehicleClass->class_name); ?></span>
                            </div>
                        </div>
                               
                                    <div class="listing-rating card-popup-rainingvis" data-starrating2="5">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <?php if($vehicle->driver->total_ratting): ?>
                                            <?php echo e($vehicle->driver->total_ratting); ?>

                                        <?php else: ?>
                                            0
                                        <?php endif; ?>

                                        Reviews
                                    </div>
                                </div>
                                <div class="TravelGo-category-img">
                                    <a href="javascript:viod(0)" data-toggle="modal" data-target="#exampleModalCenter" onclick="setVehicleInfo(<?php echo $vehicle->id; ?>)">
                                        <?php if($vehicle->image): ?>
                                        <img src="<?php echo e(asset('backend/images/vehicles/'.$vehicle->image)); ?>" alt="car_image">
                                        <?php else: ?>
                                        <img src="<?php echo e(asset('backend/images/vehicles/vehicle.png')); ?>" alt="car_image">
                                        <?php endif; ?>
                                    </a>
                                </div>
                                <div class="TravelGo-category-content fl-wrap title-sin_item">
                                    <div class="TravelGo-category-content-title fl-wrap">
                                        <div class="TravelGo-category-content-title-item">
                                            <h3 class="title-sin_map">
                                                <?php echo e($vehicle->vehicle_name); ?>

                                            </h3>
                                            <div class="TravelGo-category-location fl-wrap">
                                                <a href="javascript:void()" class="map-item">
                                                    <i class="fas fa-car-side"></i>&nbsp; <?php echo e($vehicle->vehicleClass->class_name); ?>

                                                </a> 
                                                <span style="text-transform: uppercase;">
                                                    <?php echo e($price); ?>

                                                    <?php echo e(Session::get('currency')); ?>

                                                 </span> 
                                            </div>
                                        </div>
                                    </div>

                                    <div class="car-info">
                                        <ul class="facilities-list fl-wrap">
                                            
                                            <li> <strong>Seats: <?php echo e($vehicle->seats); ?></strong></li>
                                            <button type="button" class="btn btn-primary btn-sm custom-btn" data-toggle="modal" data-target="#exampleModalCenter" onclick="setVehicleInfo(<?php echo $vehicle->id; ?>)">BOOK NOW</button>
                                        </ul>
                                    </div>
                                </div>
                            </article>
                        </div>
                    </div>
                    <input type="hidden" value="<?php echo e($price); ?>" class="priceList">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end popular car section<?php /**PATH D:\xampp7.3\htdocs\crm\resources\views/frontend/cars.blade.php ENDPATH**/ ?>