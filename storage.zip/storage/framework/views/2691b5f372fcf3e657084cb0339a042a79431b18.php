
<?php $__env->startSection('content'); ?>

<!-- contact form section -->
<section class="pt60 pb60 eleform">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <article class="TravelGo-category-listing fl-wrap">
                    <div class="TravelGo-category-content fl-wrap title-sin_item">
                        <div class="TravelGo-category-content-title fl-wrap NeedHelp">
                            <div class="TravelGo-category-content-title-item">
                                <h3 class="title-sin_map">
                                    <a href="hotel-detailed.html">Need Help?</a>
                                </h3>
                                <div class="TravelGo-category-location fl-wrap"></div>
                            </div>
                        </div>
                        <div class="NeedhelpSection">
                            <p>We would be more than happy to help you. Our team advisor are 24/7 at your service to help you.</p>
                            <ul>
                                <li>
                                    <span><i class="fas fa-phone-volume"></i></span>
                                    +921 215 2154 214
                                </li>
                                <li>
                                    <span><i class="far fa-envelope"></i></span>
                                    en.moazzam@gmail.com
                                </li>
                                <li>
                                    <span><i class="fab fa-skype"></i></span>
                                    live:infomoazzamhossain
                                </li>
                                <li>
                                    <span><i class="fab fa-skype"></i></span>
                                    live:infomoazzamhossain
                                </li>
                            </ul>
                        </div>
                    </div>
                </article>
            </div>
            <div class="col-md-6">
                <!-- Email -->
                <div class="form-group">
                    <input class="form-control" type="text" placeholder="Name">
                </div>
                <!-- Email -->
                <div class="form-group">
                    <input class="form-control" type="email" placeholder="Email">
                </div>
                <!-- Email -->
                <div class="form-group">
                    <input class="form-control" type="text" placeholder="Subject">
                </div>
                <!-- Textarea -->
                <div class="form-group">
                    <textarea class="form-control" rows="5" placeholder="Example textarea"></textarea>
                </div>
                <div class="form-group">
                    <button class="btn btn-primary btn-lg btn-grad float-right custom-btn" type="submit">Submit</button>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end contact form section -->

<!-- map section -->
<section class="contact-page pt60 pb60">
    <div class="container">
        <div class="row">
            <!-- Google default iframe Map -->
            <div class="col-md-12">
                <div class="contact-map overflow-hidden">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.840108181602!2d144.95373631539218!3d-37.8172139797516!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad65d4c2b349649%3A0xb6899234e561db11!2sEnvato!5e0!3m2!1sen!2sin!4v1525626298674" style="border:0; width:100%; height:450px;" allowfullscreen=""></iframe>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end map section -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moazz/public_html/crm/resources/views/frontend/contact.blade.php ENDPATH**/ ?>