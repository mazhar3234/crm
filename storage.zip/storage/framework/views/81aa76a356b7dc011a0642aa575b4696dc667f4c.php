
<header class="header-static navbar-sticky navbar-light shadow custom-header">
    <!-- navbar top start -->

    <!-- navbar top end-->

    <!-- logo nav start -->
    <nav class="navbar navbar-expand-lg custom-navbar">
        <div class="container">
            <!-- logo -->
            <a class="navbar-brand" href="<?php echo e(URL::to('/')); ?>"> <img src="<?php echo e(asset('/frontend/images/logo/logo_2.png')); ?>" alt="travelgo"></a>
            <!-- menu collapse button -->
            <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <!-- main menu start -->
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav ml-auto">
                    <!-- menu item -->
                    <li class="nav-item active">
                        <a class="nav-link" href="<?php echo e(URL::to('/')); ?>" aria-expanded="false">
                            <?php if(Session::get('language') == 'russian'): ?>
                                Дом
                            <?php else: ?>
                                Home
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#booking" aria-expanded="false" id="transferMenu">
                            <?php if(Session::get('language') == 'russian'): ?>
                                СПЛАНИРУЙ ТУР
                            <?php else: ?>
                                Trip Planer
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(URL::to('tours')); ?>" aria-expanded="false">
                            <?php if(Session::get('language') == 'russian'): ?>
                                ТУРЫ
                            <?php else: ?>
                                Tour
                            <?php endif; ?>
                            
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(URL::to('contact-us')); ?>" aria-expanded="false">
                            <?php if(Session::get('language') == 'russian'): ?>
                                КОНТАКТ
                            <?php else: ?>
                                Contact
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="docMenu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="text-transform: uppercase;"><?php echo e(Session::get('currency')); ?></a>
                        <ul class="dropdown-menu language" aria-labelledby="docMenu">
                            <?php if(Session::get('currency') != 'gel'): ?>
                            <li>
                                <a class="dropdown-item" href="<?php echo e(URL::to('/currency/gel')); ?>">GEL</a>
                            </li>
                            <?php endif; ?>
                            <?php if(Session::get('currency') != 'usd'): ?>
                            <li>
                                <a class="dropdown-item" href="<?php echo e(URL::to('/currency/usd')); ?>">USD</a>
                            </li>
                            <?php endif; ?>
                            <?php if(Session::get('currency') != 'rub'): ?>
                            <li>
                                <a class="dropdown-item" href="<?php echo e(URL::to('/currency/rub')); ?>">RUB</a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="docMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="text-transform: uppercase;"><img class="dropdown-item-icon" src="<?php echo e(asset('/frontend/images/component/us.svg')); ?>" alt=""><?php echo e(Session::get('language')); ?></a>
                        <ul class="dropdown-menu language" aria-labelledby="docMenu2">
                            <li>
                                <a class="dropdown-item" href="<?php echo e(URL::to('/language/english')); ?>">
                                <img class="dropdown-item-icon" src="<?php echo e(asset('/frontend/images/component/us.svg')); ?>" alt=""> English 
                            </a>
                            </li>
                            <li>
                               <a class="dropdown-item" href="<?php echo e(URL::to('/language/russian')); ?>">
                                <img class="dropdown-item-icon" src="<?php echo e(asset('/frontend/images/component/ru.svg')); ?>" alt=""> Russian
                            </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- logo nav end -->
</header>
<!-- header end<?php /**PATH D:\xampp7.3\htdocs\crm\resources\views/frontend/layouts/header.blade.php ENDPATH**/ ?>