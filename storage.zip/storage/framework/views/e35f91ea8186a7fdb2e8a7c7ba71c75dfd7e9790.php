<!doctype html>
<html lang="<?php echo e(str_replace('-', '_', app()->getLocale())); ?>">

<head>
    <!-- meta infos -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- style sheet -->
    <?php echo e(Html::style('/frontend/css/style.css')); ?>

    <?php echo e(Html::style('/frontend/css/bootstrap-datepicker.css')); ?>

    <?php echo e(Html::style('/frontend/css/select2.min.css')); ?>

    <?php echo e(Html::style('/frontend/css/custom.css')); ?>

    <!-- favicon -->
    <?php echo e(Html::favicon('/frontend/images/logo/favicon.png')); ?>

    <?php echo e(Html::favicon('/frontend/images/logo/apple-touch-icon.png')); ?>

    <title><?php echo e(config('app.name')); ?></title>
</head>

<body><?php /**PATH /home/moazz/public_html/crm/resources/views/frontend/layouts/top.blade.php ENDPATH**/ ?>