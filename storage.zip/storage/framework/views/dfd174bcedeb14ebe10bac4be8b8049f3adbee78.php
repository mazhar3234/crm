<?php echo $__env->make('backend.layouts.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="app-container app-theme-white body-tabs-shadow fixed-header fixed-sidebar">
        <?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- full content section -->
        <div class="app-main">
            <?php echo $__env->make('backend.layouts.left_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="app-main__outer">
                <?php echo $__env->yieldContent('content'); ?>
                
                
            </div>
        </div>
    </div>
    <?php echo $__env->make('backend.layouts.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('backend.layouts.bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.3\htdocs\crm\resources\views/backend/app.blade.php ENDPATH**/ ?>