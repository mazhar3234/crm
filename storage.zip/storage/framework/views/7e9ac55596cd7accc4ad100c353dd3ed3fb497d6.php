<?php 
$info=DB::table('contact_info')->where('info_id',1)->first();

?>

<footer class="footer footer-dark pt-6 position-relative custom-section footer">
    <div class="footer-content">
        <div class="container">
            <div class="row">
                <!-- footer widget 1 -->
                <div class="col-md-3 col-sm-6 order-sm-1">
                    <div class="widget address">
                        <a href="<?php echo e(URL::to('/')); ?>" class="footer-logo mb-3 d-block">
                            <img src="<?php echo e(asset('/frontend/images/logo/logo_2.png')); ?>">
                        </a>
                        <p>
                            <?php if(Session::get('language') == 'russian'): ?>
                                <?php echo e($info->about_rs); ?>

                            <?php else: ?>
                               <?php echo e($info->about_en); ?>

                            <?php endif; ?>
                        </p>
                    </div>
                </div>
                <!-- footer widget 2 -->
                <div class="col-md-3 col-sm-6 order-sm-3">
                    <div class="widget">
                        <h6>
                            <?php if(Session::get('language') == 'russian'): ?>
                                Быстрые ссылки
                            <?php else: ?>
                                Quick Links
                            <?php endif; ?>
                        </h6>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(URL::to('/')); ?>">Home</a>
                            </li>
                            <li class="nav-item"><a class="nav-link" href="<?php echo e(URL::to('/tours')); ?>">Tour</a></li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(URL::to('/contact-us')); ?>">Contact</a>
                            </li>
                            
                          
                        </ul>
                    </div>
                </div>

                <!-- footer widget 4 -->
                <div class="col-md-3 col-sm-4 order-sm-5">
                    <div class="widget">
                        <h6>
                            <?php if(Session::get('language') == 'russian'): ?>
                               
Социальные ссылки
                            <?php else: ?>
                               Social Links
                            <?php endif; ?>
                        </h6>
                         <ul class="social-icons">
                        <li class="social-icons-item social-facebook m-0">
                            <a class="social-icons-link w-auto px-2" target="_blank" href="<?php echo e($info->fb); ?>"><i style="font-size: 24px;" class="fab fa-facebook-f"></i></a> 
                        </li>
                        <li class="social-icons-item social-instagram m-0">
                            <a class="social-icons-link w-auto px-2" target="_blank" href="<?php echo e($info->twt); ?>"><i style="font-size: 24px;" class="fab fa-twitter"></i></a>
                        </li>
                        <li class="social-icons-item social-instagram m-0">
                            <a class="social-icons-link w-auto px-2" target="_blank" href="<?php echo e($info->link); ?>"><i style="font-size: 24px;" class="fab fa-linkedin"></i></a>
                        </li>
                        <li class="social-icons-item social-twitter m-0">
                            <a class="social-icons-link w-auto pl-2" target="_blank" href="<?php echo e($info->ins); ?>"><i style="font-size: 24px;" class="fab fa-instagram"></i></a>
                        </li>
                    </ul>
                    </div>
                </div>
                <!-- footer widget 5 -->
                <div class="col-md-3 col-sm-6 order-sm-2">
                    <div class="widget address">
                        <ul class="list-unstyled">
                            <li class="media mb-3"><i class="fas fa-map-marked-alt mr-3 display-8"></i><?php echo e($info->address); ?></li>
                            <li class="media mb-3"><i class="mr-3 display-8 fas fa-headphones-alt"></i> <?php echo e($info->phone); ?> </li>
                            <li class="media mb-3"><i class="mr-3 display-8 far fa-envelope"></i> <?php echo e($info->email); ?></li>
                           
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="divider mt-3"></div>
    <!--footer copyright -->
    <div class="footer-copyright">
        <div class="container">
            <div class="d-md-flex justify-content-between align-items-center py-3 text-center text-md-left">
                <div class="copyright-text">
                    ©2020
                    <?php if(Session::get('language') == 'russian'): ?>
                        Все права защищены
                    <?php else: ?>
                        All Rights Reserved by
                    <?php endif; ?>
                    <a target="_blank" href="https://moazzamhossain7.github.io/">Moazzam</a>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- end footer section<?php /**PATH D:\xampp7.3\htdocs\crm\resources\views/frontend/layouts/footer.blade.php ENDPATH**/ ?>