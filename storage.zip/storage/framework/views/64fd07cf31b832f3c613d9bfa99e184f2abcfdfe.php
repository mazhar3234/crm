<?php $__env->startSection('content'); ?>

<!-- main banner -->
<section class="p-0 height-700 parallax-bg tourBanner" style="background:url(/frontend/images/slider/slider_2.jpg) no-repeat 65% 0%; background-size:cover;">
    <div class="container h-100">
        <div class="row justify-content-between align-items-center h-100">
            <!-- <div class="col-md-8 mb-7">
                <h4>World's biggest online car rental service</h4>
                <h1 class="display-4 font-weight-bold">
                	Upto 25% off on first booking through your app
                </h1>
            </div> -->
        </div>
    </div>
</section>
<!-- main banner -->

<!-- booking section -->
<section class="mt-lg-n9 mt-sm-0 pb-0 z-index-9 booking-search custom-margin" id="booking">
    <div class="container ">
        <div class="row shadow border-radius-3">
            <div class="col-md-12 np">
                <div class="feature-box h-100">
                    <form name="form1" id="bookingForm">
                    <div class="tab_container">
                        <input id="tab1" type="radio" name="tabs" checked>
                        <!-- <label for="tab1"><i class="fas fa-car-side"></i><span>Cars</span></label> -->
                       
                        <section id="content1" class="tab-content" id="booking-data">
                            <div class="row" id="mainDiv">
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 padding8">
                                    <select class="from-control from-location select2" name="from_location[]" onchange="loadCars()" id="from_location">
                                        <option value="">Drop of... click to select airport or city</option>
                                        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option><?php echo e($location->location_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 padding8">
                                    <select class="from-control to-location select2" name="to_location[]" onchange="loadCars()" id="to_location">
                                        <option value="">Drop of... click to select airport or city</option>
                                        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option><?php echo e($location->location_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="copyDiv"></div>
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding8">
                                    <div class="form-group">
                                        <button class="btn btn-light btn-lg" type="button" id="add_location">
                                           <i class="fas fa-plus"></i> Add place
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding8">
                                    <div class="form-group"><span class="far fa-calendar-alt"></span>
                                        <input class="form-control" type="text" id="datepicker" autocomplete="off" placeholder="When...">
                                    </div>
                                </div> 
                            </div>
                            <p id="tripInfo" style="color: #F49122; font-size: 15px; font-weight: bold;"></p>
                        </section>
                        <input type="hidden" name="duration" id="duration">
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end booking section -->

<div id="carOutput"></div>

<!-- service section -->
<section class="bg-light bg-transparent pt80 pb60 solutions mt-custom">
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto text-center mb-5">
                <h2 class="title text-center">WE OFFER YOU</h2>
              
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <ul class="list-group list-unstyled">
  <li class="mb-3"><h4 style="font-size: 22px;"><i class="fas fa-thumbs-up"></i>  Vehicles with a best preparatory drivers</h4></li>
   <li class="mb-3"><h4 style="font-size: 22px;"><i class="fas fa-thumbs-up"></i>  Drivers that focused on your desires and consuption</h4></li>
    <li class="mb-3"><h4 style="font-size: 22px;"><i class="fas fa-thumbs-up"></i>  Comfort and safety</h4></li>
     <li><h4 style="font-size: 22px;"><i class="fas fa-thumbs-up"></i>  contact with us within 24/7</h4></li>
</ul>
            </div>
            <div class="col-md-6">
                                <ul class="list-group list-unstyled">
  <li class="mb-3"><h4 style="font-size: 22px;"><i class="fas fa-thumbs-up"></i>   Unforgettable trip to Georgia</h4></li>
   <li class="mb-3"><h4 style="font-size: 22px;"><i class="fas fa-thumbs-up"></i>  Currency exchange, shopping, selfie, etc.(for your discretion)</h4></li>
    <li class="mb-3"><h4 style="font-size: 22px;"><i class="fas fa-thumbs-up"></i> Stops at all the sights along the way</h4></li>
     <li><h4 style="font-size: 22px;"><i class="fas fa-thumbs-up"></i>  Best price, best service</h4></li>
</ul>
            </div>
        </div>
   
        <h4 style="font-size: 22px;margin-bottom:10px;" class="mt-5">
            The website  is created for convenient, reliable and simple search for your personal car with local drivers.</h4>

<h4 style="font-size: 22px;margin-bottom:10px;">Our database will contain information about each offer, the exact cost of the transfer, the characteristics of the driver and the car, the profile of the driver and their knowledge of languages. </h4>

<h4 style="font-size: 22px;margin-bottom:10px;">To select a transfer / tour you will need to specify the place of receipt and disembarkation.</h4>

<h4 style="font-size: 22px;margin-bottom:10px;">Pricing corresponds to services compared to competitive. We offer you services for better service, well-trained drivers who will be focused on your interests and convenience. With our drivers, you have the opportunity to stop and enjoy with additional sights and beautiful views that you can follow along the route and take the photos.</h4>

<h4  style="font-size: 22px;margin-bottom:10px;">Traveling with a local driver gives you the opportunity to immediately feel the originality and originality of the culture of Georgia and calmly enjoy them...
        </h4>

        <h1 style="margin-top:50px;" class="text-center">
We wish you have a good and interesting time in Georgia </h1>
    </div>
</section>
<!-- end service section -->

<!-- popular cities section -->

<!-- end popular cities section -->
    



<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.3\htdocs\crm\resources\views/frontend/index.blade.php ENDPATH**/ ?>